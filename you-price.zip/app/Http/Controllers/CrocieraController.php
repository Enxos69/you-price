<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CrocieraController extends Controller
{
    public function index()
    {
        return view('crociere.create');
    }

    public function search(Request $request)
    {
        $data = $request->validate([
            'start_date' => 'required|date',
            'budget' => 'required|numeric|min:1',
            'participants' => 'required|integer|min:1',
            'port_start' => 'nullable|string',
            'port_end' => 'nullable|string',
        ]);

        $budgetPerPerson = $data['budget'] / $data['participants'];

        $matches = DB::table('___import_crociere')
            ->whereNotNull('cruise')
            ->when($data['port_start'], fn($q) => $q->where('partenza', $data['port_start']))
            ->when($data['port_end'], fn($q) => $q->where('arrivo', $data['port_end']))
            ->whereRaw("CAST(REPLACE(interior, '€', '') AS UNSIGNED) <= ?", [$budgetPerPerson])
            ->take(5)
            ->get();

        // Punteggio base (es. %)
        $soddisfazione = $matches->count() ? min(100, 60 + $matches->count() * 10) : 30;

        // Simulazione alternativa: aumento date o rimozione porto
        $alternative = DB::table('___import_crociere')
            ->whereNotNull('cruise')
            ->take(5)
            ->get();

        return response()->json([
            'soddisfazione' => 55,
            'ottimale' => 92,
            'matches' => $matches,
            'alternative' => $alternative,
        ]);
    }
}
