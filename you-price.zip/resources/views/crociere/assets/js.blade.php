<script>
document.addEventListener('DOMContentLoaded', function () {
  const form = document.querySelector('#search-form');
  const resultsSection = document.querySelector('#results-section');
  const gauge1 = document.getElementById('gaugeAttuale');
  const gauge2 = document.getElementById('gaugeOttimale');

  let chart1, chart2;

  form.addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = new FormData(form);
    const params = Object.fromEntries(formData.entries());

    const res = await fetch('/crociere/search', {
      method: 'POST',
      headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
      body: formData
    });

    const data = await res.json();
    resultsSection.classList.remove('d-none');

    drawGauge(gauge1, data.soddisfazione, chart1 => chart1 = chart1);
    drawGauge(gauge2, data.ottimale, chart2 => chart2 = chart2);

    fillTable('table-matches', data.matches);
    fillTable('table-suggestions', data.alternative);
  });

  function drawGauge(canvas, value, cb) {
    if (cb) cb.destroy?.();
    cb(
      new Chart(canvas, {
        type: 'doughnut',
        data: {
          datasets: [{
            data: [value, 100 - value],
            backgroundColor: ['#f58634', '#e0e0e0'],
            borderWidth: 0
          }]
        },
        options: {
          rotation: -90,
          circumference: 180,
          cutout: '80%',
          plugins: {
            tooltip: { enabled: false },
            legend: { display: false },
            title: {
              display: true,
              text: value + ' %',
              font: { size: 24 }
            }
          }
        }
      })
    );
  }

  function fillTable(id, items) {
    const tbody = document.querySelector(`#${id} tbody`);
    tbody.innerHTML = '';
    items.forEach(row => {
      const tr = document.createElement('tr');
      tr.innerHTML = id === 'table-matches'
        ? `<td>${row.ship}</td><td>${row.line}</td><td>${row.night}</td><td>${row.interior}</td><td>${row.partenza}</td>`
        : `<td>${row.ship}</td><td>${row.line}</td><td>${row.interior}</td><td>${row.partenza}</td>`;
      tbody.appendChild(tr);
    });
  }
});
</script>