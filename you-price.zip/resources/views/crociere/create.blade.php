@extends('layouts.app')

@section('content')
    <div class="container py-4">

        {{-- FORM RICHIESTA CROCIERA --}}
        <div class="card shadow-sm mb-4 p-4">
            <h2 class="mb-3">Richiedi una crociera</h2>
            <form id="search-form">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label>Periodo *</label>
                        <input type="date" name="start_date" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label>Budget disponibile (€) *</label>
                        <input type="number" name="budget" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label>Numero partecipanti *</label>
                        <input type="number" name="participants" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label>Porto di partenza</label>
                        <input type="text" name="port_start" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label>Porto di destinazione</label>
                        <input type="text" name="port_end" class="form-control">
                    </div>
                </div>
                <div class="text-end mt-3">
                    <button class="btn btn-primary">Cerca crociera</button>
                </div>
            </form>
        </div>

        {{-- SEZIONE GRAFICI --}}
        <div id="results-section" class="d-none">
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="card p-4 text-center">
                        <h5>Soddisfazione richiesta attuale</h5>
                        <canvas id="gaugeAttuale" height="200"></canvas>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-4 text-center">
                        <h5>Suggerimento con parametri ottimizzati</h5>
                        <canvas id="gaugeOttimale" height="200"></canvas>
                    </div>
                </div>
            </div>

            {{-- TABELLE CROCIERE --}}
            <div class="row g-4">
                <div class="col-md-6">
                    <div class="card p-3">
                        <h6 class="fw-bold mb-2">Crociere compatibili</h6>
                        <table class="table table-striped table-sm" id="table-matches">
                            <thead>
                                <tr>
                                    <th>Nave</th>
                                    <th>Compagnia</th>
                                    <th>Notti</th>
                                    <th>Prezzo</th>
                                    <th>Partenza</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card p-3">
                        <h6 class="fw-bold mb-2">Crociere alternative consigliate</h6>
                        <table class="table table-striped table-sm" id="table-suggestions">
                            <thead>
                                <tr>
                                    <th>Nave</th>
                                    <th>Compagnia</th>
                                    <th>Prezzo</th>
                                    <th>Partenza</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection

@section('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    @parent
    @include('crociere.assets.js')
@endsection
