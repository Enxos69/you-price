<?php

return [
    'email' => 'Indirizzo email',
    'password' => 'Password',
    'confirm_password' => 'Conferma la Password',
    'login' => 'Accedi',
    'register' => 'Registrati',
    'remember_me' => 'Ricordami',
    'forgot_password' => 'Hai dimenticato la password?',    
    'name' => 'Nome',
    'surname' => 'Cognome',
];
