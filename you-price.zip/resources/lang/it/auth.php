<?php

return [
    'failed' => 'Queste credenziali non corrispondono ai nostri record.',
    'password' => 'La password fornita non è corretta.',
    'throttle' => 'Troppi tentativi di login. Riprova tra :seconds secondi.',
];
