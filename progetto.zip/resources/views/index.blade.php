<!-- resources/views/index.blade.php -->
@extends('layouts.app')

@section('content')
<div style='background-image: url("/assets/img/home_background.jpg");' id="homepage" >   
    <!-- Main Content -->
    {{-- <div class="jumbotron text-center mt-5 pt-5">
        <h1>Benvenuto nel nostro sito!</h1>
        <p>Questa è la pagina iniziale. Accedi o registrati per continuare.</p>
    </div>   --}}    
</div>
@endsection

 