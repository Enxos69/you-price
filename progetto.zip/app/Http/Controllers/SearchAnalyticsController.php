<?php

namespace App\Http\Controllers;

use App\Models\SearchLog;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Cache;
use Carbon\Carbon;

class SearchAnalyticsController extends Controller
{
    /**
     * Costruttore - middleware di autenticazione admin
     */
    public function __construct()
    {
        $this->middleware(function ($request, $next) {
            if (!Auth::check() || Auth::user()->role !== '1') {
                return redirect('/home')->with('error', 'Accesso negato - Solo amministratori');
            }
            return $next($request);
        });
    }

    /**
     * Dashboard principale analytics
     */
    public function index()
    {
        return view('admin.analytics.index');
    }

    /**
     * Statistiche generali con cache
     */
    public function getGeneralStats()
    {
        return $this->cacheResponse('general_stats', function () {
            $today = Carbon::today();
            $yesterday = $today->copy()->subDay();

            $stats = [
                // Contatori principali
                'total_searches' => SearchLog::count(),
                'successful_searches' => SearchLog::where('search_successful', true)->count(),
                'registered_users_searches' => SearchLog::whereNotNull('user_id')->count(),
                'guest_searches' => SearchLog::whereNull('user_id')->count(),

                // Metriche qualitative
                'avg_satisfaction' => round(SearchLog::avg('satisfaction_score') ?? 0, 1),
                'avg_search_duration' => round(SearchLog::avg('search_duration_ms') ?? 0),
                'total_matches_found' => SearchLog::sum('total_matches') ?? 0,
                'avg_budget' => round(SearchLog::avg('budget') ?? 0, 2),

                // Statistiche giornaliere
                'today_searches' => SearchLog::whereDate('search_date', $today)->count(),
                'yesterday_searches' => SearchLog::whereDate('search_date', $yesterday)->count(),

                // Partecipanti più comuni
                'most_popular_participants' => $this->getMostPopularParticipants(),
            ];

            // Calcola variazione percentuale giornaliera
            $stats['daily_change_percent'] = $this->calculatePercentageChange(
                $stats['today_searches'],
                $stats['yesterday_searches']
            );

            return $stats;
        }, 300); // Cache per 5 minuti
    }

    /**
     * Trend ricerche con parametri personalizzabili
     */
    public function getSearchTrends(Request $request)
    {
        $days = min(max($request->get('days', 30), 1), 365); // Limita tra 1 e 365 giorni

        return $this->cacheResponse("search_trends_{$days}", function () use ($days) {
            return SearchLog::selectRaw('
                DATE(search_date) as date,
                COUNT(*) as total_searches,
                COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_searches,
                ROUND(AVG(satisfaction_score), 1) as avg_satisfaction,
                ROUND(AVG(search_duration_ms)) as avg_duration,
                COUNT(DISTINCT user_id) as unique_users
            ')
                ->where('search_date', '>=', Carbon::now()->subDays($days))
                ->groupBy('date')
                ->orderBy('date')
                ->get();
        }, 600); // Cache per 10 minuti
    }

    /**
     * Statistiche dispositivi e browser ottimizzate
     */
    public function getDeviceStats()
    {
        return $this->cacheResponse('device_stats', function () {
            // Query per dispositivi - corretta
            $devices = SearchLog::selectRaw('
                device_type,
                COUNT(*) as count,
                ROUND(AVG(COALESCE(search_duration_ms, 0))) as avg_duration,
                ROUND(AVG(COALESCE(satisfaction_score, 0)), 1) as avg_satisfaction,
                COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_count
            ')
                ->whereNotNull('device_type')
                ->groupBy('device_type')
                ->orderBy('count', 'desc')
                ->get();

            $devicesFormatted = $devices->map(function ($item) {
                return [
                    'device_type' => $item->device_type,
                    'count' => (int) $item->count,
                    'avg_duration' => (int) $item->avg_duration,
                    'avg_satisfaction' => (float) $item->avg_satisfaction,
                    'success_rate' => $item->count > 0 ?
                        round(($item->successful_count / $item->count) * 100, 1) : 0
                ];
            });

            // Query per browser
            $browsers = SearchLog::selectRaw('
                browser,
                COUNT(*) as count,
                ROUND(AVG(COALESCE(search_duration_ms, 0))) as avg_duration,
                ROUND(AVG(COALESCE(satisfaction_score, 0)), 1) as avg_satisfaction,
                COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_count
            ')
                ->whereNotNull('browser')
                ->groupBy('browser')
                ->orderBy('count', 'desc')
                ->limit(10)
                ->get();

            $browsersFormatted = $browsers->map(function ($item) {
                return [
                    'browser' => $item->browser,
                    'count' => (int) $item->count,
                    'avg_duration' => (int) $item->avg_duration,
                    'avg_satisfaction' => (float) $item->avg_satisfaction,
                    'success_rate' => $item->count > 0 ?
                        round(($item->successful_count / $item->count) * 100, 1) : 0
                ];
            });

            // Query per sistemi operativi
            $operatingSystems = SearchLog::selectRaw('
                operating_system,
                COUNT(*) as count,
                ROUND(AVG(COALESCE(search_duration_ms, 0))) as avg_duration,
                ROUND(AVG(COALESCE(satisfaction_score, 0)), 1) as avg_satisfaction,
                COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_count
            ')
                ->whereNotNull('operating_system')
                ->groupBy('operating_system')
                ->orderBy('count', 'desc')
                ->limit(10)
                ->get();

            $osFormatted = $operatingSystems->map(function ($item) {
                return [
                    'operating_system' => $item->operating_system,
                    'count' => (int) $item->count,
                    'avg_duration' => (int) $item->avg_duration,
                    'avg_satisfaction' => (float) $item->avg_satisfaction,
                    'success_rate' => $item->count > 0 ?
                        round(($item->successful_count / $item->count) * 100, 1) : 0
                ];
            });

            return [
                'devices' => $devicesFormatted->toArray(),
                'browsers' => $browsersFormatted->toArray(),
                'operating_systems' => $osFormatted->toArray()
            ];
        }, 900);
    }

    /**
     * Statistiche geografiche ottimizzate - CORRETTO
     */
    public function getGeographicStats()
    {
        return $this->cacheResponse('geographic_stats', function () {
            // Ottieni dati geografici grezzi con aggregazione corretta
            $countriesData = SearchLog::selectRaw('
            country,
            COUNT(*) as searches,
            AVG(COALESCE(search_duration_ms, 0)) as avg_duration,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction,
            COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_searches
        ')
                ->whereNotNull('country')
                ->where('country', '!=', '')
                ->where('country', '!=', 'Local')
                ->groupBy('country')
                ->orderBy('searches', 'desc')
                ->limit(15)
                ->get();

            $citiesData = SearchLog::selectRaw('
            city,
            country,
            COUNT(*) as searches,
            AVG(COALESCE(search_duration_ms, 0)) as avg_duration,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction,
            COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_searches
        ')
                ->whereNotNull('city')
                ->whereNotNull('country')
                ->where('city', '!=', '')
                ->where('country', '!=', 'Local')
                ->groupBy('city', 'country')
                ->orderBy('searches', 'desc')
                ->limit(10)
                ->get();

            $ispsData = SearchLog::selectRaw('
            isp,
            COUNT(*) as searches,
            AVG(COALESCE(search_duration_ms, 0)) as avg_duration,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction
        ')
                ->whereNotNull('isp')
                ->where('isp', '!=', '')
                ->groupBy('isp')
                ->orderBy('searches', 'desc')
                ->limit(10)
                ->get();

            return [
                'countries' => $countriesData->map(function ($item) {
                    return [
                        'country' => $item->country,
                        'searches' => (int) $item->searches, // IMPORTANTE: 'searches', non 'count'
                        'avg_duration' => round($item->avg_duration ?? 0),
                        'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1),
                        'success_rate' => $item->searches > 0 ?
                            round(($item->successful_searches / $item->searches) * 100, 1) : 0
                    ];
                })->toArray(),

                'cities' => $citiesData->map(function ($item) {
                    return [
                        'city' => $item->city,
                        'country' => $item->country,
                        'searches' => (int) $item->searches,
                        'avg_duration' => round($item->avg_duration ?? 0),
                        'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1),
                        'success_rate' => $item->searches > 0 ?
                            round(($item->successful_searches / $item->searches) * 100, 1) : 0
                    ];
                })->toArray(),

                'isps' => $ispsData->map(function ($item) {
                    return [
                        'isp' => $item->isp,
                        'searches' => (int) $item->searches,
                        'avg_duration' => round($item->avg_duration ?? 0),
                        'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1)
                    ];
                })->toArray()
            ];
        }, 1800); // Cache per 30 minuti
    }


    /**
     * Statistiche parametri di ricerca
     */
    public function getSearchParametersStats()
    {
        return $this->cacheResponse('search_parameters', function () {
            return [
                'budget_ranges' => $this->getBudgetDistribution(),
                'participants' => $this->getParticipantsDistribution(),
                'popular_ports' => $this->getPopularPorts(),
                'monthly_patterns' => $this->getMonthlyPatterns(),
                'seasonal_trends' => $this->getSeasonalTrends()
            ];
        }, 1800);
    }


    /**
     * Performance metrics avanzate - CORRETTO
     */
    public function getPerformanceMetrics()
    {
        return $this->cacheResponse('performance_metrics', function () {
            // Query base per metriche generali
            $metrics = DB::selectOne('
                SELECT 
                    AVG(search_duration_ms) as avg_duration,
                    MIN(search_duration_ms) as min_duration,
                    MAX(search_duration_ms) as max_duration,
                    COUNT(CASE WHEN search_duration_ms > 3000 THEN 1 END) as slow_searches,
                    COUNT(CASE WHEN search_successful = 0 THEN 1 END) as failed_searches,
                    COUNT(*) as total_searches
                FROM search_logs 
                WHERE search_duration_ms IS NOT NULL
            ');

            // Calcolo del 95° percentile compatibile con MySQL
            $totalCount = DB::table('search_logs')->whereNotNull('search_duration_ms')->count();
            $skipCount = (int) floor($totalCount * 0.95);

            $p95Duration = DB::table('search_logs')
                ->whereNotNull('search_duration_ms')
                ->orderBy('search_duration_ms')
                ->skip($skipCount)
                ->take(1)
                ->value('search_duration_ms') ?? 0;

            // Aggiunge il 95° percentile ai risultati
            if ($metrics) {
                $metrics->p95_duration = $p95Duration;
            }

            $devicePerformance = SearchLog::selectRaw('
                device_type,
                AVG(search_duration_ms) as avg_duration,
                COUNT(*) as searches,
                AVG(satisfaction_score) as avg_satisfaction,
                COUNT(CASE WHEN search_successful = 1 THEN 1 END) as successful_searches
            ')
                ->whereNotNull('device_type')
                ->whereNotNull('search_duration_ms')
                ->groupBy('device_type')
                ->get();

            $commonErrors = SearchLog::selectRaw('
                error_message,
                COUNT(*) as occurrences,
                MAX(DATE(search_date)) as last_occurrence
            ')
                ->whereNotNull('error_message')
                ->where('search_successful', false)
                ->groupBy('error_message')
                ->orderBy('occurrences', 'desc')
                ->limit(5)
                ->get();

            return [
                'overall_metrics' => $metrics,
                'device_performance' => $devicePerformance,
                'common_errors' => $commonErrors,
                'performance_score' => $this->calculatePerformanceScore($metrics)
            ];
        }, 600); // Cache per 10 minuti
    }
    /**
     * Log ricerche con filtri avanzati e paginazione ottimizzata - CORRETTO
     */
    public function getSearchLogs(Request $request)
    {
        $query = SearchLog::with(['user:id,name,surname,email'])
            ->select([
                'id',
                'user_id',
                'search_date',
                'date_range',
                'budget',
                'participants',
                'port_start',
                'total_matches',
                'total_alternatives',
                'satisfaction_score',
                'device_type',
                'operating_system',
                'browser',
                'browser_version',
                'country',
                'city',
                'isp',
                'ip_address',
                'search_duration_ms',
                'search_successful',
                'error_message',
                'is_guest'
            ])
            ->orderBy('search_date', 'desc');

        // Applica filtri in modo efficiente
        $this->applyFilters($query, $request);

        try {
            $logs = $query->paginate($request->get('per_page', 25));

            // IMPORTANTE: Trasforma i dati in formato semplice per JavaScript
            $transformedData = $logs->getCollection()->map(function ($log) {
                return $this->transformLogForResponse($log);
            });

            // Restituisci struttura semplificata per DataTable
            return response()->json([
                'current_page' => $logs->currentPage(),
                'last_page' => $logs->lastPage(),
                'per_page' => $logs->perPage(),
                'total' => $logs->total(),
                'from' => $logs->firstItem(),
                'to' => $logs->lastItem(),
                'data' => $transformedData->toArray() // IMPORTANTE: ->toArray()
            ]);
        } catch (\Exception $e) {
            Log::error('Errore caricamento logs: ' . $e->getMessage());
            return response()->json([
                'error' => 'Errore nel caricamento dei log: ' . $e->getMessage(),
                'data' => [],
                'current_page' => 1,
                'last_page' => 1,
                'total' => 0
            ], 500);
        }
    }


    /**
     * Export CSV ottimizzato
     */
    public function exportCsv(Request $request)
    {
        try {
            $query = SearchLog::with('user:id,name,surname,email')
                ->orderBy('search_date', 'desc');

            $this->applyFilters($query, $request);

            $filename = 'search_analytics_' . date('Ymd_His') . '.csv';
            $headers = [
                'Content-Type' => 'text/csv; charset=UTF-8',
                'Content-Disposition' => 'attachment; filename="' . $filename . '"',
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
                'Pragma' => 'no-cache',
                'Expires' => '0'
            ];

            return response()->stream(function () use ($query) {
                $this->generateCsvStream($query);
            }, 200, $headers);
        } catch (\Exception $e) {
            Log::error('Errore export CSV: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Errore durante l\'export: ' . $e->getMessage());
        }
    }

    /**
     * Executive summary per dashboard dirigenziale
     */
    public function getExecutiveSummary()
    {
        return $this->cacheResponse('executive_summary', function () {
            $now = Carbon::now();
            $today = $now->copy()->startOfDay();
            $lastWeek = $now->copy()->subWeek();
            $lastMonth = $now->copy()->subMonth();

            $summary = [
                // KPI principali
                'kpis' => $this->getMainKPIs($today, $lastWeek, $lastMonth),

                // Trend crescita
                'growth_trends' => $this->getGrowthTrends($today, $lastWeek, $lastMonth),

                // Performance indicators
                'performance_indicators' => $this->getPerformanceIndicators(),

                // Top insights
                'top_insights' => $this->getTopInsights(),

                // Alerting
                'alerts' => $this->getSystemAlerts()
            ];

            return $summary;
        }, 300); // Cache per 5 minuti
    }

    /**
     * Pulizia log vecchi con controlli di sicurezza
     */
    public function cleanupOldLogs(Request $request)
    {
        $request->validate([
            'days' => 'required|integer|min:90|max:730', // Min 3 mesi, max 2 anni
            'confirm' => 'required|boolean|accepted'
        ]);

        try {
            DB::beginTransaction();

            $cutoffDate = Carbon::now()->subDays($request->days);
            $toDeleteCount = SearchLog::where('search_date', '<', $cutoffDate)->count();

            // Controllo di sicurezza: non eliminare più del 70% dei dati
            $totalRecords = SearchLog::count();
            if ($toDeleteCount > ($totalRecords * 0.7)) {
                throw new \Exception('Operazione bloccata: si sta tentando di eliminare troppi record');
            }

            $deletedCount = SearchLog::where('search_date', '<', $cutoffDate)->delete();

            DB::commit();

            // Invalida cache
            $this->clearCache();

            Log::info("Pulizia log completata: eliminati {$deletedCount} record più vecchi di {$request->days} giorni", [
                'admin_user' => Auth::id(),
                'deleted_count' => $deletedCount,
                'cutoff_date' => $cutoffDate->toDateString()
            ]);

            return response()->json([
                'success' => true,
                'message' => "Eliminati {$deletedCount} log più vecchi di {$request->days} giorni",
                'deleted_count' => $deletedCount,
                'remaining_count' => $totalRecords - $deletedCount
            ]);
        } catch (\Exception $e) {
            DB::rollback();
            Log::error('Errore pulizia logs: ' . $e->getMessage());

            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== METODI HELPER PRIVATI ====================

    /**
     * Cache response con gestione errori
     */
    private function cacheResponse($key, $callback, $ttl = 300)
    {
        try {
            return Cache::remember("analytics_{$key}", $ttl, $callback);
        } catch (\Exception $e) {
            Log::error("Errore cache analytics ({$key}): " . $e->getMessage());
            return $callback(); // Fallback senza cache
        }
    }

    /**
     * Calcola variazione percentuale
     */
    private function calculatePercentageChange($current, $previous)
    {
        if ($previous == 0) {
            return $current > 0 ? 100 : 0;
        }
        return round((($current - $previous) / $previous) * 100, 1);
    }

    /**
     * Ottiene partecipanti più comuni
     */
    private function getMostPopularParticipants()
    {
        return SearchLog::selectRaw('participants, COUNT(*) as count')
            ->whereNotNull('participants')
            ->groupBy('participants')
            ->orderBy('count', 'desc')
            ->value('participants') ?? 2;
    }

    /**
     * Aggrega top città con paese
     */
    private function aggregateTopCities($geoData, $limit)
    {
        return $geoData->groupBy('city')->map(function ($group, $city) {
            $country = $group->first()->country;
            return [
                'city' => $city,
                'country' => $country,
                'searches' => $group->sum('searches'),
                'avg_duration' => round($group->avg('avg_duration') ?? 0),
                'success_rate' => $group->sum('searches') > 0 ?
                    round(($group->sum('successful_searches') / $group->sum('searches')) * 100, 1) : 0
            ];
        })->sortByDesc('searches')->take($limit)->values();
    }

    /**
     * Distribuzione budget ottimizzata
     */
    private function getBudgetDistribution()
    {
        try {
            $budgetData = SearchLog::selectRaw('
            CASE 
                WHEN budget < 1000 THEN "0-999"
                WHEN budget < 2000 THEN "1000-1999"
                WHEN budget < 3000 THEN "2000-2999"
                WHEN budget < 5000 THEN "3000-4999"
                ELSE "5000+"
            END as budget_range,
            COUNT(*) as count,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction,
            AVG(COALESCE(participants, 2)) as avg_participants
        ')
                ->whereNotNull('budget')
                ->where('budget', '>', 0)
                ->groupBy('budget_range')
                ->orderByRaw('MIN(budget)')
                ->get();

            // IMPORTANTE: Converti Collection in array associativo semplice
            $result = [];
            foreach ($budgetData as $item) {
                $result[$item->budget_range] = [
                    'count' => (int) $item->count,
                    'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1),
                    'avg_participants' => round($item->avg_participants ?? 2, 1)
                ];
            }

            // Assicurati che tutti i range esistano anche se vuoti
            $allRanges = ['0-999', '1000-1999', '2000-2999', '3000-4999', '5000+'];
            foreach ($allRanges as $range) {
                if (!isset($result[$range])) {
                    $result[$range] = [
                        'count' => 0,
                        'avg_satisfaction' => 0,
                        'avg_participants' => 0
                    ];
                }
            }

            return $result; // Restituisce array semplice, non Collection
        } catch (\Exception $e) {
            Log::error('Errore getBudgetDistribution: ' . $e->getMessage());

            // Restituisci struttura di fallback
            return [
                '0-999' => ['count' => 0, 'avg_satisfaction' => 0, 'avg_participants' => 0],
                '1000-1999' => ['count' => 0, 'avg_satisfaction' => 0, 'avg_participants' => 0],
                '2000-2999' => ['count' => 0, 'avg_satisfaction' => 0, 'avg_participants' => 0],
                '3000-4999' => ['count' => 0, 'avg_satisfaction' => 0, 'avg_participants' => 0],
                '5000+' => ['count' => 0, 'avg_satisfaction' => 0, 'avg_participants' => 0]
            ];
        }
    }


    /**
     * Distribuzione partecipanti - CORRETTO per Laravel Collection
     */
    private function getParticipantsDistribution()
    {
        try {
            $participantsData = SearchLog::selectRaw('
            participants,
            COUNT(*) as count,
            AVG(COALESCE(budget, 0)) as avg_budget,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction
        ')
                ->whereNotNull('participants')
                ->where('participants', '>', 0)
                ->where('participants', '<=', 10)
                ->groupBy('participants')
                ->orderBy('participants')
                ->get();

            // IMPORTANTE: Converti Collection in array semplice
            return $participantsData->map(function ($item) {
                return [
                    'participants' => (int) $item->participants,
                    'count' => (int) $item->count,
                    'avg_budget' => round($item->avg_budget ?? 0),
                    'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1)
                ];
            })->toArray(); // IMPORTANTE: ->toArray() per convertire Collection

        } catch (\Exception $e) {
            Log::error('Errore getParticipantsDistribution: ' . $e->getMessage());
            return [];
        }
    }


    /**
     * Porti più ricercati - CORRETTO per Laravel Collection
     */
    private function getPopularPorts()
    {
        try {
            $portsData = SearchLog::selectRaw('
            port_start,
            COUNT(*) as searches,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction,
            COUNT(CASE WHEN total_matches > 0 THEN 1 END) as searches_with_results
        ')
                ->whereNotNull('port_start')
                ->where('port_start', '!=', '')
                ->groupBy('port_start')
                ->orderBy('searches', 'desc')
                ->limit(15) // Aumentato da 10 a 15 per avere più dati
                ->get();

            // IMPORTANTE: Converti Collection in array semplice
            return $portsData->map(function ($item) {
                return [
                    'port_start' => $item->port_start,
                    'searches' => (int) $item->searches,
                    'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1),
                    'searches_with_results' => (int) $item->searches_with_results
                ];
            })->toArray(); // IMPORTANTE: ->toArray()

        } catch (\Exception $e) {
            Log::error('Errore getPopularPorts: ' . $e->getMessage());
            return [];
        }
    }


    /**
     * Pattern mensili - CORRETTO per Laravel Collection
     */
    private function getMonthlyPatterns()
    {
        try {
            $monthlyData = SearchLog::selectRaw('
            CASE 
                WHEN date_range REGEXP "(^|/)0?1/" THEN "Gennaio"
                WHEN date_range REGEXP "(^|/)0?2/" THEN "Febbraio"
                WHEN date_range REGEXP "(^|/)0?3/" THEN "Marzo"
                WHEN date_range REGEXP "(^|/)0?4/" THEN "Aprile"
                WHEN date_range REGEXP "(^|/)0?5/" THEN "Maggio"
                WHEN date_range REGEXP "(^|/)0?6/" THEN "Giugno"
                WHEN date_range REGEXP "(^|/)0?7/" THEN "Luglio"
                WHEN date_range REGEXP "(^|/)0?8/" THEN "Agosto"
                WHEN date_range REGEXP "(^|/)0?9/" THEN "Settembre"
                WHEN date_range REGEXP "(^|/)10/" THEN "Ottobre"
                WHEN date_range REGEXP "(^|/)11/" THEN "Novembre"
                WHEN date_range REGEXP "(^|/)12/" THEN "Dicembre"
                ELSE "Altro"
            END as month,
            COUNT(*) as searches,
            AVG(COALESCE(budget, 0)) as avg_budget
        ')
                ->whereNotNull('date_range')
                ->groupBy('month')
                ->orderBy('searches', 'desc')
                ->get();

            // IMPORTANTE: Converti Collection in array semplice
            return $monthlyData->map(function ($item) {
                return [
                    'month' => $item->month,
                    'searches' => (int) $item->searches,
                    'avg_budget' => round($item->avg_budget ?? 0)
                ];
            })->toArray(); // IMPORTANTE: ->toArray()

        } catch (\Exception $e) {
            Log::error('Errore getMonthlyPatterns: ' . $e->getMessage());
            return [];
        }
    }


    /**
     * Trend stagionali - CORRETTO per Laravel Collection
     */
    private function getSeasonalTrends()
    {
        try {
            $seasonalData = SearchLog::selectRaw('
            QUARTER(search_date) as quarter,
            YEAR(search_date) as year,
            COUNT(*) as searches,
            AVG(COALESCE(satisfaction_score, 0)) as avg_satisfaction
        ')
                ->groupBy('quarter', 'year')
                ->orderBy('year', 'desc')
                ->orderBy('quarter', 'desc')
                ->limit(8)
                ->get();

            // IMPORTANTE: Converti Collection in array semplice
            return $seasonalData->map(function ($item) {
                return [
                    'quarter' => (int) $item->quarter,
                    'year' => (int) $item->year,
                    'searches' => (int) $item->searches,
                    'avg_satisfaction' => round($item->avg_satisfaction ?? 0, 1)
                ];
            })->toArray(); // IMPORTANTE: ->toArray()

        } catch (\Exception $e) {
            Log::error('Errore getSeasonalTrends: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Calcola performance score
     */
    private function calculatePerformanceScore($metrics)
    {
        if (!$metrics) return 0;

        $score = 100;

        // Penalizza per durata alta
        if ($metrics->avg_duration > 2000) $score -= 20;
        elseif ($metrics->avg_duration > 1500) $score -= 10;

        // Penalizza per ricerche lente
        $slowPercentage = ($metrics->slow_searches / $metrics->total_searches) * 100;
        if ($slowPercentage > 10) $score -= 30;
        elseif ($slowPercentage > 5) $score -= 15;

        // Penalizza per fallimenti
        $failureRate = ($metrics->failed_searches / $metrics->total_searches) * 100;
        if ($failureRate > 5) $score -= 25;
        elseif ($failureRate > 2) $score -= 10;

        return max($score, 0);
    }

    /**
     * Applica filtri alla query
     */
    private function applyFilters($query, $request)
    {
        if ($request->filled('user_type')) {
            if ($request->user_type === 'registered') {
                $query->whereNotNull('user_id');
            } elseif ($request->user_type === 'guest') {
                $query->whereNull('user_id');
            }
        }

        if ($request->filled('device_type')) {
            $query->where('device_type', $request->device_type);
        }

        if ($request->filled('country')) {
            $query->where('country', $request->country);
        }

        if ($request->filled('date_from')) {
            $query->where('search_date', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->where('search_date', '<=', $request->date_to);
        }

        if ($request->filled('successful_only')) {
            $query->where('search_successful', $request->successful_only === 'true');
        }

        return $query;
    }

    /**
     * Trasforma log per response API - SEMPLIFICATO
     */
    private function transformLogForResponse($log)
    {
        // Gestisci utente
        $userName = 'Ospite';
        $userEmail = '';
        if ($log->user) {
            $userName = trim(($log->user->name ?? '') . ' ' . ($log->user->surname ?? ''));
            $userEmail = $log->user->email ?? '';
        }

        // Gestisci device info con fallback
        $deviceType = $log->device_type ?? 'N/D';
        $operatingSystem = $log->operating_system ?? '';
        $browser = $log->browser ?? '';
        if ($log->browser_version) {
            $browser .= ' ' . $log->browser_version;
        }

        // Gestisci location con fallback
        $country = $log->country ?? 'N/D';
        $city = $log->city ?? '';
        $isp = $log->isp ?? '';

        // Gestisci parametri ricerca
        $dateRange = $log->date_range ?? 'N/D';
        $budget = $log->budget ?? 0;
        $participants = $log->participants ?? 0;
        $portStart = $log->port_start ?? '';

        // Gestisci risultati
        $totalMatches = $log->total_matches ?? 0;
        $totalAlternatives = $log->total_alternatives ?? 0;
        $satisfactionScore = $log->satisfaction_score ?? 0;

        // Gestisci performance
        $searchDuration = $log->search_duration_ms ?? 0;
        $searchSuccessful = $log->search_successful ?? false;
        $errorMessage = $log->error_message ?? '';

        return [
            'id' => $log->id,
            'search_date' => $log->search_date ? $log->search_date->format('d/m/y H:i') : 'N/D',

            // Utente
            'user_name' => $userName,
            'user_email' => $userEmail,
            'user_type' => $log->user ? 'Registrato' : 'Ospite',
            'is_guest' => $log->user ? false : true,

            // Device
            'device_type' => $deviceType,
            'operating_system' => $operatingSystem,
            'browser' => $browser,
            'browser_full' => trim($browser . ' ' . $operatingSystem),

            // Parametri
            'date_range' => $dateRange,
            'budget' => (int) $budget,
            'participants' => (int) $participants,
            'port_start' => $portStart,

            // Risultati
            'total_matches' => (int) $totalMatches,
            'total_alternatives' => (int) $totalAlternatives,
            'satisfaction_score' => round($satisfactionScore, 1),

            // Location
            'country' => $country,
            'city' => $city,
            'isp' => $isp,
            'location_full' => trim($city . ', ' . $country),

            // Performance
            'search_duration_ms' => (int) $searchDuration,
            'search_successful' => $searchSuccessful,
            'error_message' => $errorMessage,

            // Status
            'status' => $searchSuccessful ? 'success' : 'error'
        ];
    }


    /**
     * Genera stream CSV ottimizzato
     */
    private function generateCsvStream($query)
    {
        $file = fopen('php://output', 'w');
        fputs($file, "\xEF\xBB\xBF"); // BOM UTF-8

        // Header CSV
        fputcsv($file, [
            'ID',
            'Data Ricerca',
            'Utente',
            'Tipo Utente',
            'Periodo Ricerca',
            'Budget',
            'Partecipanti',
            'Porto Partenza',
            'Risultati Trovati',
            'Alternative',
            'Soddisfazione %',
            'Dispositivo',
            'Sistema Operativo',
            'Browser',
            'Paese',
            'Città',
            'ISP',
            'IP',
            'Durata (ms)',
            'Successo',
            'Messaggio Errore'
        ], ';');

        // Dati in chunks per ottimizzare memoria
        $query->chunk(500, function ($logs) use ($file) {
            foreach ($logs as $log) {
                $userName = $log->user ?
                    trim($log->user->name . ' ' . $log->user->surname) . ' (' . $log->user->email . ')' :
                    'Ospite';

                fputcsv($file, [
                    $log->id,
                    $log->search_date->format('d/m/Y H:i:s'),
                    $userName,
                    $log->user ? 'Registrato' : 'Ospite',
                    $log->date_range,
                    $log->budget,
                    $log->participants,
                    $log->port_start,
                    $log->total_matches,
                    $log->total_alternatives,
                    $log->satisfaction_score,
                    $log->device_type,
                    $log->operating_system,
                    $log->browser . ($log->browser_version ? ' ' . $log->browser_version : ''),
                    $log->country,
                    $log->city,
                    $log->isp,
                    $log->ip_address,
                    $log->search_duration_ms,
                    $log->search_successful ? 'Sì' : 'No',
                    $log->error_message
                ], ';');
            }
        });

        fclose($file);
    }

    /**
     * KPI principali per executive summary
     */
    private function getMainKPIs($today, $lastWeek, $lastMonth)
    {
        return [
            'total_searches' => SearchLog::count(),
            'success_rate' => $this->calculateSuccessRate(),
            'avg_satisfaction' => round(SearchLog::avg('satisfaction_score') ?? 0, 1),
            'avg_response_time' => round(SearchLog::avg('search_duration_ms') ?? 0),
            'unique_users_month' => SearchLog::where('search_date', '>=', $lastMonth)
                ->distinct('user_id')->count('user_id'),
            'mobile_usage_rate' => $this->calculateDevicePercentage('mobile')
        ];
    }

    /**
     * Trend di crescita
     */
    private function getGrowthTrends($today, $lastWeek, $lastMonth)
    {
        return [
            'daily_growth' => $this->calculateGrowthRate('day'),
            'weekly_growth' => $this->calculateGrowthRate('week'),
            'monthly_growth' => $this->calculateGrowthRate('month')
        ];
    }

    /**
     * Indicatori di performance
     */
    private function getPerformanceIndicators()
    {
        $avgDuration = SearchLog::avg('search_duration_ms') ?? 0;
        $successRate = $this->calculateSuccessRate();

        return [
            'response_time_status' => $avgDuration < 1500 ? 'excellent' : ($avgDuration < 3000 ? 'good' : 'poor'),
            'success_rate_status' => $successRate > 95 ? 'excellent' : ($successRate > 90 ? 'good' : 'poor'),
            'error_rate' => round((1 - $successRate / 100) * 100, 2),
            'slow_queries_percentage' => $this->getSlowQueriesPercentage()
        ];
    }

    /**
     * Top insights
     */
    private function getTopInsights()
    {
        return [
            'peak_hour' => $this->getPeakHour(),
            'top_country' => $this->getTopCountry(),
            'avg_budget' => round(SearchLog::avg('budget') ?? 0),
            'most_common_participants' => $this->getMostPopularParticipants()
        ];
    }

    /**
     * System alerts
     */
    private function getSystemAlerts()
    {
        $alerts = [];

        // Alert per performance
        $avgDuration = SearchLog::avg('search_duration_ms') ?? 0;
        if ($avgDuration > 3000) {
            $alerts[] = [
                'type' => 'warning',
                'message' => 'Tempo di risposta medio elevato: ' . round($avgDuration) . 'ms'
            ];
        }

        // Alert per tasso di errore
        $errorRate = 100 - $this->calculateSuccessRate();
        if ($errorRate > 5) {
            $alerts[] = [
                'type' => 'error',
                'message' => 'Tasso di errore elevato: ' . round($errorRate, 1) . '%'
            ];
        }

        return $alerts;
    }

    /**
     * Calcola tasso di successo
     */
    private function calculateSuccessRate()
    {
        $total = SearchLog::count();
        if ($total == 0) return 100;

        $successful = SearchLog::where('search_successful', true)->count();
        return round(($successful / $total) * 100, 1);
    }

    /**
     * Calcola percentuale dispositivo specifico
     */
    private function calculateDevicePercentage($deviceType)
    {
        $total = SearchLog::whereNotNull('device_type')->count();
        if ($total == 0) return 0;

        $deviceCount = SearchLog::where('device_type', $deviceType)->count();
        return round(($deviceCount / $total) * 100, 1);
    }

    /**
     * Calcola tasso di crescita per periodo
     */
    private function calculateGrowthRate($period)
    {
        $now = Carbon::now();

        switch ($period) {
            case 'day':
                $current = SearchLog::whereDate('search_date', $now->toDateString())->count();
                $previous = SearchLog::whereDate('search_date', $now->subDay()->toDateString())->count();
                break;
            case 'week':
                $current = SearchLog::whereBetween('search_date', [
                    $now->startOfWeek(),
                    $now->endOfWeek()
                ])->count();
                $previous = SearchLog::whereBetween('search_date', [
                    $now->subWeek()->startOfWeek(),
                    $now->subWeek()->endOfWeek()
                ])->count();
                break;
            case 'month':
                $current = SearchLog::whereBetween('search_date', [
                    $now->startOfMonth(),
                    $now->endOfMonth()
                ])->count();
                $previous = SearchLog::whereBetween('search_date', [
                    $now->subMonth()->startOfMonth(),
                    $now->subMonth()->endOfMonth()
                ])->count();
                break;
            default:
                return 0;
        }

        return $this->calculatePercentageChange($current, $previous);
    }

    /**
     * Ottiene percentuale query lente
     */
    private function getSlowQueriesPercentage()
    {
        $total = SearchLog::whereNotNull('search_duration_ms')->count();
        if ($total == 0) return 0;

        $slow = SearchLog::where('search_duration_ms', '>', 3000)->count();
        return round(($slow / $total) * 100, 1);
    }

    /**
     * Ottiene ora di picco
     */
    private function getPeakHour()
    {
        $result = SearchLog::selectRaw('HOUR(search_date) as hour, COUNT(*) as count')
            ->groupBy('hour')
            ->orderBy('count', 'desc')
            ->first();

        return $result ? $result->hour . ':00' : 'N/D';
    }

    /**
     * Ottiene paese principale
     */
    private function getTopCountry()
    {
        $result = SearchLog::selectRaw('country, COUNT(*) as count')
            ->whereNotNull('country')
            ->where('country', '!=', 'Local')
            ->groupBy('country')
            ->orderBy('count', 'desc')
            ->first();

        return $result ? $result->country : 'N/D';
    }

    /**
     * METODO TEMPORANEO - Pulisce cache per test
     */
    public function clearAnalyticsCache()
    {
        $this->clearCache();

        return response()->json([
            'success' => true,
            'message' => 'Cache analytics pulita'
        ]);
    }

    /**
     * METODO TEMPORANEO - Debug device data
     * Rimuovi dopo aver testato
     */
    public function debugDeviceData()
    {
        $rawData = SearchLog::selectRaw('
            device_type,
            COUNT(*) as count
        ')
            ->whereNotNull('device_type')
            ->groupBy('device_type')
            ->get();

        $allDeviceTypes = SearchLog::select('device_type')
            ->whereNotNull('device_type')
            ->get()
            ->pluck('device_type')
            ->toArray();

        return response()->json([
            'raw_grouped_data' => $rawData,
            'all_device_types' => array_count_values($allDeviceTypes),
            'total_records' => SearchLog::count(),
            'records_with_device_type' => SearchLog::whereNotNull('device_type')->count(),
            'sample_records' => SearchLog::select('id', 'device_type', 'browser', 'operating_system')
                ->whereNotNull('device_type')
                ->limit(10)
                ->get()
        ]);
    }

    /**
     * METODO TEMPORANEO - Crea dati di test per analytics
     * Rimuovi dopo aver testato
     */
    public function createTestData()
    {
        try {
            // Crea alcuni log di test solo se la tabella è vuota
            if (SearchLog::count() === 0) {
                $testLogs = [
                    [
                        'user_id' => Auth::id(),
                        'search_date' => now()->subHours(2),
                        'date_range' => '15/09/2025 - 22/09/2025',
                        'budget' => 2000,
                        'participants' => 2,
                        'port_start' => 'Civitavecchia',
                        'total_matches' => 5,
                        'total_alternatives' => 8,
                        'satisfaction_score' => 85.5,
                        'search_duration_ms' => 1250,
                        'search_successful' => true,
                        'device_type' => 'desktop',
                        'operating_system' => 'Windows 10',
                        'browser' => 'Chrome',
                        'browser_version' => '120.0',
                        'country' => 'Italy',
                        'city' => 'Roma',
                        'isp' => 'TIM',
                        'is_guest' => false
                    ],
                    [
                        'user_id' => null,
                        'search_date' => now()->subHour(),
                        'date_range' => '01/10/2025 - 07/10/2025',
                        'budget' => 1500,
                        'participants' => 4,
                        'port_start' => 'Barcellona',
                        'total_matches' => 3,
                        'total_alternatives' => 12,
                        'satisfaction_score' => 72.0,
                        'search_duration_ms' => 890,
                        'search_successful' => true,
                        'device_type' => 'mobile',
                        'operating_system' => 'iOS',
                        'browser' => 'Safari',
                        'browser_version' => '17.0',
                        'country' => 'Spain',
                        'city' => 'Barcelona',
                        'isp' => 'Vodafone',
                        'is_guest' => true
                    ],
                    [
                        'user_id' => null,
                        'search_date' => now()->subMinutes(30),
                        'date_range' => '20/11/2025 - 27/11/2025',
                        'budget' => 3500,
                        'participants' => 2,
                        'port_start' => 'Venezia',
                        'total_matches' => 0,
                        'total_alternatives' => 2,
                        'satisfaction_score' => 45.0,
                        'search_duration_ms' => 3200,
                        'search_successful' => false,
                        'error_message' => 'Nessuna crociera disponibile per i parametri richiesti',
                        'device_type' => 'tablet',
                        'operating_system' => 'Android',
                        'browser' => 'Chrome',
                        'browser_version' => '119.0',
                        'country' => 'Italy',
                        'city' => 'Milano',
                        'isp' => 'Fastweb',
                        'is_guest' => true
                    ]
                ];

                foreach ($testLogs as $logData) {
                    SearchLog::create($logData);
                }

                return response()->json([
                    'success' => true,
                    'message' => 'Creati ' . count($testLogs) . ' log di test',
                    'count' => count($testLogs)
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'La tabella contiene già dati (' . SearchLog::count() . ' record)'
                ]);
            }
        } catch (\Exception $e) {
            Log::error('Errore creazione dati test: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Pulisce cache analytics
     */
    private function clearCache()
    {
        $keys = [
            'general_stats',
            'device_stats',
            'geographic_stats',
            'search_parameters',
            'performance_metrics',
            'executive_summary'
        ];

        foreach ($keys as $key) {
            Cache::forget("analytics_{$key}");
        }

        // Pulisce anche cache dei trend per vari periodi
        for ($days = 7; $days <= 365; $days += 7) {
            Cache::forget("analytics_search_trends_{$days}");
        }
    }
}
